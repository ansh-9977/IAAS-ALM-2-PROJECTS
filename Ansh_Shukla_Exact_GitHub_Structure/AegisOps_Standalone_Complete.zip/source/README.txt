AEGISOPS STANDALONE - WINDOWS 64-BIT

Run AegisOps_Standalone_Windows.exe by double-clicking it.
The application displays BACKEND ONLINE in its terminal and opens one dashboard in your default web browser.
Keep the terminal window open while using the app. Press Ctrl+C or close it to stop the app.
An unused 127.0.0.1 port is chosen automatically. No internet or install required.

FEATURES: Real RSA-2048 / OAEP / PSS, self-signed X.509 demonstration certificates, X25519 ECDH and AES-128-GCM. Teaching simulations: TLS, SSH, IPsec, Elgamal signature steps, IDS and firewall packet decisions.

LIMITS: This is a new independent educational implementation based on the provided report, not the missing original React/Flask project source. No actual firewall changes, live network monitoring, external SSH/TLS/IPsec connections, or certificate authority trust. Key material is stored only in RAM and lost on exit.

SOURCE: main.go + index.html + go.mod; compile with Go 1.23 or newer: go build -o AegisOps_Standalone_Windows.exe .
