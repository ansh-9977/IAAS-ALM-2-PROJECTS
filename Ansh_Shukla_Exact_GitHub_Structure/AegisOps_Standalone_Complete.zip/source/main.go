package main

import (
	"crypto"
	"crypto/aes"
	"crypto/cipher"
	"crypto/ecdh"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"crypto/sha512"
	"crypto/x509"
	"crypto/x509/pkix"
	_ "embed"
	"encoding/base64"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"log"
	"math"
	"math/big"
	"net"
	"net/http"
	"os/exec"
	"runtime"
	"sort"
	"strings"
	"sync"
	"time"
)

//go:embed index.html
var page []byte
var store = struct {
	sync.Mutex
	key       *rsa.PrivateKey
	user      string
	cert      string
	encrypted []byte
	signature []byte
	aesKey    []byte
	nonce     []byte
}{}

type Req struct {
	Action      string    `json:"action"`
	Message     string    `json:"message"`
	Username    string    `json:"username"`
	IP          string    `json:"ip"`
	Port        int       `json:"port"`
	Protocol    string    `json:"protocol"`
	Destination string    `json:"destination"`
	Failures    int       `json:"failures"`
	Ports       []int     `json:"ports"`
	Samples     []float64 `json:"samples"`
	Current     float64   `json:"current"`
	Mode        string    `json:"mode"`
}
type Result map[string]any

func reply(w http.ResponseWriter, status int, data Result) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(data)
}
func pemPublic(k *rsa.PublicKey) string {
	data, _ := x509.MarshalPKIXPublicKey(k)
	return string(pem.EncodeToMemory(&pem.Block{Type: "PUBLIC KEY", Bytes: data}))
}
func api(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		reply(w, 405, Result{"error": "POST required"})
		return
	}
	r.Body = http.MaxBytesReader(w, r.Body, 100000)
	var a Req
	if err := json.NewDecoder(r.Body).Decode(&a); err != nil {
		reply(w, 400, Result{"error": "Invalid request"})
		return
	}
	data, err := operate(a)
	if err != nil {
		reply(w, 400, Result{"error": err.Error()})
		return
	}
	reply(w, 200, data)
}
func operate(a Req) (Result, error) {
	switch a.Action {
	case "enroll":
		user := strings.TrimSpace(a.Username)
		if user == "" {
			return nil, errors.New("Enter a name to create an identity")
		}
		key, err := rsa.GenerateKey(rand.Reader, 2048)
		if err != nil {
			return nil, err
		}
		serial, err := rand.Int(rand.Reader, new(big.Int).Lsh(big.NewInt(1), 128))
		if err != nil {
			return nil, err
		}
		certTemplate := &x509.Certificate{SerialNumber: serial, Subject: pkix.Name{CommonName: user, Organization: []string{"AegisOps Demonstration CA"}}, NotBefore: time.Now().Add(-time.Minute), NotAfter: time.Now().Add(24 * time.Hour), KeyUsage: x509.KeyUsageDigitalSignature | x509.KeyUsageKeyEncipherment, BasicConstraintsValid: true, IsCA: false}
		raw, err := x509.CreateCertificate(rand.Reader, certTemplate, certTemplate, &key.PublicKey, key)
		if err != nil {
			return nil, err
		}
		cert := string(pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: raw}))
		store.Lock()
		store.key = key
		store.user = user
		store.cert = cert
		store.Unlock()
		return Result{"status": "Identity enrolled", "user": user, "publicKey": pemPublic(&key.PublicKey), "certificate": cert, "detail": "A 2048-bit RSA key pair and self-signed demonstration certificate were generated in memory."}, nil
	case "encrypt":
		store.Lock()
		defer store.Unlock()
		if store.key == nil {
			return nil, errors.New("Enroll an identity first")
		}
		if a.Message == "" {
			return nil, errors.New("Enter a message")
		}
		if len(a.Message) > 190 {
			return nil, errors.New("RSA-OAEP (2048/SHA-256) input must be 190 bytes or fewer")
		}
		enc, err := rsa.EncryptOAEP(sha256.New(), rand.Reader, &store.key.PublicKey, []byte(a.Message), nil)
		if err != nil {
			return nil, err
		}
		store.encrypted = enc
		return Result{"ciphertext": base64.StdEncoding.EncodeToString(enc), "detail": "Real RSA-2048 OAEP with SHA-256, Base64 output"}, nil
	case "decrypt":
		store.Lock()
		defer store.Unlock()
		if store.key == nil || len(store.encrypted) == 0 {
			return nil, errors.New("Encrypt a message first")
		}
		dec, err := rsa.DecryptOAEP(sha256.New(), rand.Reader, store.key, store.encrypted, nil)
		if err != nil {
			return nil, err
		}
		return Result{"plaintext": string(dec), "detail": "Recovered from RSA ciphertext using private key"}, nil
	case "sign":
		store.Lock()
		defer store.Unlock()
		if store.key == nil {
			return nil, errors.New("Enroll an identity first")
		}
		h := sha256.Sum256([]byte(a.Message))
		sig, err := rsa.SignPSS(rand.Reader, store.key, cryptoHash(), h[:], nil)
		if err != nil {
			return nil, err
		}
		store.signature = sig
		return Result{"signature": base64.StdEncoding.EncodeToString(sig), "verified": rsa.VerifyPSS(&store.key.PublicKey, cryptoHash(), h[:], sig, nil) == nil, "detail": "RSA-PSS + SHA-256"}, nil
	case "dh":
		curve := ecdh.X25519()
		alice, err := curve.GenerateKey(rand.Reader)
		if err != nil {
			return nil, err
		}
		bob, err := curve.GenerateKey(rand.Reader)
		if err != nil {
			return nil, err
		}
		k1, err := alice.ECDH(bob.PublicKey())
		if err != nil {
			return nil, err
		}
		k2, err := bob.ECDH(alice.PublicKey())
		if err != nil {
			return nil, err
		}
		h := sha256.Sum256(k1)
		return Result{"alicePublic": base64.StdEncoding.EncodeToString(alice.PublicKey().Bytes()), "bobPublic": base64.StdEncoding.EncodeToString(bob.PublicKey().Bytes()), "sharedSecretDigest": fmt.Sprintf("%x", h), "match": string(k1) == string(k2), "detail": "Real X25519 ECDH. The shared secret itself is not displayed; its SHA-256 digest is shown."}, nil
	case "elgamal":
		// Deliberately report illustrative status instead of mislabeling an unrelated signature as Elgamal.
		sum := sha512.Sum512([]byte(a.Message))
		return Result{"digest": fmt.Sprintf("%x", sum), "detail": "SHA-512 digest computed. Elgamal signing is a conceptual demonstration only in this standalone edition.", "steps": []string{"Choose domain parameters p, g and private value x", "Compute public key y = g^x mod p", "Select a fresh random k coprime to p-1", "Compute r = g^k mod p and s = k^-1(H(m)-xr) mod (p-1)", "Verify g^H(m) = y^r r^s (mod p)"}}, nil
	case "tls":
		secret := make([]byte, 16)
		if _, err := rand.Read(secret); err != nil {
			return nil, err
		}
		store.Lock()
		store.aesKey = secret
		store.Unlock()
		return Result{"steps": []string{"1. ClientHello: supported protocol versions, random value, algorithms", "2. ServerHello: selected version and cipher suite", "3. Certificate presentation and identity validation (conceptual)", "4. Session keys derived and AES-128-GCM key created locally", "5. Finished verification and protected application traffic (conceptual)"}, "keyReady": true, "detail": "Teaching simulation of a TLS 1.3-style flow; not a production TLS protocol implementation."}, nil
	case "aesencrypt":
		store.Lock()
		key := append([]byte(nil), store.aesKey...)
		store.Unlock()
		if len(key) == 0 {
			return nil, errors.New("Initialize TLS session first")
		}
		block, err := aes.NewCipher(key)
		if err != nil {
			return nil, err
		}
		gcm, err := cipher.NewGCM(block)
		if err != nil {
			return nil, err
		}
		nonce := make([]byte, gcm.NonceSize())
		if _, err := rand.Read(nonce); err != nil {
			return nil, err
		}
		ciphertext := gcm.Seal(nil, nonce, []byte(a.Message), nil)
		plain, err := gcm.Open(nil, nonce, ciphertext, nil)
		if err != nil {
			return nil, err
		}
		return Result{"nonce": base64.StdEncoding.EncodeToString(nonce), "ciphertext": base64.StdEncoding.EncodeToString(ciphertext), "decrypted": string(plain), "detail": "Real AES-128-GCM encryption and authenticated decryption; demo session key is in memory."}, nil
	case "ssh":
		return Result{"steps": []string{"1. TCP connection to SSH endpoint", "2. SSH protocol version and algorithm negotiation", "3. Diffie-Hellman-style key exchange", "4. Verify the server host key fingerprint", "5. Authenticate user with a supported method", "6. Open an encrypted remote shell channel"}, "detail": "Illustrative sequence only; no SSH server or remote shell is created."}, nil
	case "ipsec":
		mode := a.Mode
		if mode != "tunnel" {
			mode = "transport"
		}
		if mode == "tunnel" {
			return Result{"mode": mode, "packet": "[Outer IP header] [ESP header] [Encrypted: Original IP header + TCP/UDP + Data + ESP trailer] [Integrity tag]", "detail": "Conceptual ESP tunnel encapsulation, not an actual VPN tunnel."}, nil
		}
		return Result{"mode": mode, "packet": "[Original IP header] [ESP header] [Encrypted: TCP/UDP + Data + ESP trailer] [Integrity tag]", "detail": "Conceptual ESP transport encapsulation, not an actual IPsec connection."}, nil
	case "firewall":
		protocol := strings.ToUpper(strings.TrimSpace(a.Protocol))
		if protocol == "" {
			protocol = "TCP"
		}
		ip := strings.TrimSpace(a.IP)
		if net.ParseIP(ip) == nil {
			return nil, errors.New("Enter a valid source IP address")
		}
		if a.Port < 1 || a.Port > 65535 {
			return nil, errors.New("Port must be 1–65535")
		}
		type rule struct {
			priority        int
			verdict, reason string
			match           func() bool
		}
		rules := []rule{
			{10, "BLOCK", "Telnet is denied", func() bool { return protocol == "TCP" && a.Port == 23 }},
			{20, "ALLOW", "SSH administration via approved subnet", func() bool { return protocol == "TCP" && a.Port == 22 && strings.HasPrefix(ip, "192.168.1.") }},
			{30, "ALLOW", "HTTPS traffic", func() bool { return protocol == "TCP" && a.Port == 443 }},
			{40, "ALLOW", "DNS traffic", func() bool { return (protocol == "UDP" || protocol == "TCP") && a.Port == 53 }},
		}
		sort.Slice(rules, func(i, j int) bool { return rules[i].priority < rules[j].priority })
		for _, rule := range rules {
			if rule.match() {
				return Result{"verdict": rule.verdict, "reason": rule.reason, "priority": rule.priority, "detail": "Demonstration evaluation only; no OS firewall settings are changed."}, nil
			}
		}
		return Result{"verdict": "BLOCK", "reason": "Default-deny: no allow rule matched", "priority": "default", "detail": "Demonstration evaluation only; no OS firewall settings are changed."}, nil
	case "ids":
		alerts := []string{}
		if a.Failures >= 5 {
			alerts = append(alerts, "Possible SSH brute force: 5 or more failed logins")
		}
		if a.Port == 23 {
			alerts = append(alerts, "Unencrypted Telnet traffic observed")
		}
		if len(a.Ports) >= 8 {
			uniq := map[int]bool{}
			for _, p := range a.Ports {
				uniq[p] = true
			}
			if len(uniq) >= 8 {
				alerts = append(alerts, "Potential port scan: 8+ unique destination ports")
			}
		}
		if len(alerts) == 0 {
			alerts = append(alerts, "No signature rule triggered by the provided sample")
		}
		return Result{"alerts": alerts, "detail": "Educational rule-based classification; not live packet capture."}, nil
	case "anomaly":
		samples := a.Samples
		if len(samples) < 3 {
			return nil, errors.New("Provide at least 3 historical packet-rate samples")
		}
		mean := 0.0
		for _, x := range samples {
			if math.IsNaN(x) || math.IsInf(x, 0) || x < 0 {
				return nil, errors.New("Invalid sample")
			}
			mean += x
		}
		mean /= float64(len(samples))
		variance := 0.0
		for _, x := range samples {
			variance += (x - mean) * (x - mean)
		}
		variance /= float64(len(samples))
		sigma := math.Sqrt(variance)
		threshold := mean + 3*sigma
		return Result{"mean": mean, "stddev": sigma, "threshold": threshold, "current": a.Current, "anomaly": a.Current > threshold, "detail": "Three-sigma threshold (mean + 3 × population standard deviation). Historical sample only."}, nil
	default:
		return nil, errors.New("Unknown operation")
	}
}
func cryptoHash() crypto.Hash { return crypto.SHA256 }
func main() {
	mux := http.NewServeMux()
	mux.HandleFunc("/api/", api)
	mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		reply(w, 200, Result{"status": "online", "name": "AegisOps Standalone", "modules": 3})
	})
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Write(page)
	})
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		log.Fatal(err)
	}
	url := "http://" + ln.Addr().String()
	fmt.Println("AEGISOPS BACKEND ONLINE: " + url)
	fmt.Println("Keep this window running. Press Ctrl+C to stop.")
	go func() {
		time.Sleep(450 * time.Millisecond)
		var cmd *exec.Cmd
		switch runtime.GOOS {
		case "windows":
			cmd = exec.Command("rundll32", "url.dll,FileProtocolHandler", url)
		case "darwin":
			cmd = exec.Command("open", url)
		default:
			cmd = exec.Command("xdg-open", url)
		}
		_ = cmd.Start()
	}()
	server := &http.Server{Handler: mux, ReadHeaderTimeout: 5 * time.Second}
	log.Fatal(server.Serve(ln))
}
