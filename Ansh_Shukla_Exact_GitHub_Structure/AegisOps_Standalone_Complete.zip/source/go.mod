module aegisops

go 1.23
